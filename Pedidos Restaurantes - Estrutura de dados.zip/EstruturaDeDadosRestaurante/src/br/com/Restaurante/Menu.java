package br.com.Restaurante;

import java.util.Scanner;

public class Menu {
	
	Scanner sc = new Scanner(System.in); 
	
	VetorPedidos pedidos = new VetorPedidos(5);

	public void menu() {
		
		System.out.println("\nDigite uma op��o valida:\n");
		System.out.println("|	1 --> Fazer um pedido:\n");
		System.out.println("|	2 --> Vereficar qual ser� o proximo pedido a ser entregue:\n");
		System.out.println("|	3 --> Cancelar �ltimo pedido:\n");
		System.out.println("|	4 --> Ver quantidade de pedidos / Mostrar pedidos:\n");
		System.out.println("|	5 --> SAIR!:\n");
		
		int opc = 0;
		
		System.out.println("\nOp��o: ");
		opc = sc.nextInt();
		
		switch (opc) {
		case 1:
			inserirPedido();
			break;
			
		case 2:
			vereficarPedido();
			break;
			
		case 3:
			cancelarPedido();
			break;
			
		case 4:
			vereficarPedidos();
			break;
			
		case 5:
			return;

		default:
			System.out.println("Op��o invalida");
			menu();
			break;
		}
		sc.close();
	}
	
	public void inserirPedido() {
		
		String nomePedido = null;
		float precoPedido = 0;
		
		System.out.println("\n\nDigite o nome do pedido: ");
		nomePedido = sc.next();
		
		System.out.println("\nValor do pedido: ");
		precoPedido = sc.nextFloat();
		
		Pedido pedido1 = new Pedido(nomePedido, precoPedido);
		
		try {
			pedidos.adiciona(pedido1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		menu();
		
	}
	
	public void vereficarPedido() {
		
		int tamanho = pedidos.tamanho();
		System.out.println("Proximo pedido a ser entregue: ");
		//pedidos.busca(tamanho - 1);
		System.out.println(pedidos.busca(tamanho - 1).toString());
		
		menu();
		
	}
	
	public void cancelarPedido() {
		
		int tamanho = pedidos.tamanho();
		pedidos.remove(tamanho - 1);
		
		menu();
		
	}
	
	public void vereficarPedidos() {
		
		int tamanho = pedidos.tamanho();
		
		System.out.println(tamanho + " pedidos em fila\n");
		
		for(int i = tamanho - 1; i >= 0; i--) {
			System.out.println(pedidos.busca(i).toString());
			System.out.println("\n");
		}
		
		menu();
	}

}
