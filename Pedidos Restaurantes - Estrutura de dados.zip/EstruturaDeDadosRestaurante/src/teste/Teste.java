package teste;

import br.com.Restaurante.Menu;

public class Teste {

	public static void main(String[] args) {
		
		Menu menuzinho = new Menu();
		menuzinho.menu();
	}

}
