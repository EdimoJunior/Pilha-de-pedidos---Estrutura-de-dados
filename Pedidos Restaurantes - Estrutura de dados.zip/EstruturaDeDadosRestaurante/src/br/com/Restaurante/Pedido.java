package br.com.Restaurante;

public class Pedido {
	
	String nome;
	Float preco;
	
	public Pedido (String pnome, Float ppreco) {
		this.nome = pnome;
		this.preco = ppreco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Float getPreco() {
		return preco;
	}

	public void setPreco(Float preco) {
		this.preco = preco;
	}

	@Override
	public String toString() {
		return "Pedido [nome=" + nome + ", preco=" + preco + "]";
	}

}
